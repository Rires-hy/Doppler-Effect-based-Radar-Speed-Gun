This project was developed in STM32CubeIDE

Copyright EEEE2059(2020) Group 6. All rights reserved.

USART1 is used for external LED display communication.
USART2 is used for USB connection to upper monitor such as PC.
PB6 -> USART1_TX
PB7 -> USART1_RX
USART1 baud rate is set as and must be 57600 bits/s
USART2 baud rate is set as 57600 bits/s

PA0 -> ADC_INPUT

This program is only used for final demonstration!